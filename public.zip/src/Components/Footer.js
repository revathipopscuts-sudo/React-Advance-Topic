import { Box, Typography, Container, Link } from "@mui/material";

function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <Box
      component="footer"
      sx={{
        bgcolor: 'primary.main',
        color: 'white',
        py: 3,
        mt: 'auto', // Push footer to bottom
      }}
    >
      <Container maxWidth="lg">
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: 2
          }}
        >
          <Typography variant="body2">
            © {currentYear} React Forms App. All rights reserved.
          </Typography>
          
          <Box sx={{ display: 'flex', gap: 2 }}>
            <Link 
              href="#" 
              color="inherit" 
              underline="hover"
              onClick={(e) => {
                e.preventDefault();
                // Add your privacy policy navigation
                console.log("Privacy Policy clicked");
              }}
            >
              Privacy Policy
            </Link>
            <Link 
              href="#" 
              color="inherit" 
              underline="hover"
              onClick={(e) => {
                e.preventDefault();
                // Add your terms of service navigation
                console.log("Terms of Service clicked");
              }}
            >
              Terms of Service
            </Link>
            <Link 
              href="#" 
              color="inherit" 
              underline="hover"
              onClick={(e) => {
                e.preventDefault();
                // Add your contact navigation
                console.log("Contact clicked");
              }}
            >
              Contact
            </Link>
          </Box>
        </Box>
      </Container>
    </Box>
  );
}

export default Footer;