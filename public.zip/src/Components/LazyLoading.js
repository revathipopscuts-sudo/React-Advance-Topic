import "./styles.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { lazy, Suspense } from "react";
import ProtectedRoute from "./Components/ProtectedRoute";
import Login from "./Pages/Login";
import Layout from "./Components/Layout";
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { CssBaseline, Box, CircularProgress, Typography } from "@mui/material";
import { ToastContainer } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import ErrorBoundary from "./Components/ErrorBoundary";

// Security: Lazy load components with proper error handling
const Dashboard = lazy(() => 
  import("./Pages/Dashboard").catch(error => {
    console.error('Failed to load Dashboard component:', error);
    // Return fallback component in case of chunk load failure
    return { default: () => <div>Error loading Dashboard. Please refresh the page.</div> };
  })
);

const Profile = lazy(() => 
  import("./Pages/Profile").catch(error => {
    console.error('Failed to load Profile component:', error);
    return { default: () => <div>Error loading Profile. Please refresh the page.</div> };
  })
);

const Home = lazy(() => 
  import("./Pages/Home").catch(error => {
    console.error('Failed to load Home component:', error);
    return { default: () => <div>Error loading Home. Please refresh the page.</div> };
  })
);

// Security: Secure loading component that doesn't expose system information
const SecureLoadingFallback = ({ componentName = "page" }) => (
  <Box
    sx={{
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',
      minHeight: '200px',
      p: 3,
    }}
  >
    <CircularProgress size={40} thickness={4} />
    <Typography 
      variant="body1" 
      sx={{ mt: 2, color: 'text.secondary' }}
    >
      Loading {componentName}...
    </Typography>
  </Box>
);

// Security: Error boundary specifically for lazy loaded components
const LazyComponentErrorBoundary = ({ children, fallback }) => (
  <ErrorBoundary>
    <Suspense fallback={<SecureLoadingFallback />}>
      {children}
    </Suspense>
  </ErrorBoundary>
);

const theme = createTheme({
  palette: {
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#42a5f5',
    },
  },
  components: {
    MuiCssBaseline: {
      styleOverrides: {
        '.no-select': {
          userSelect: 'none',
          webkitUserSelect: 'none',
          mozUserSelect: 'none',
          msUserSelect: 'none',
        },
        // Security: Hide loading states that might expose app structure
        '.loading-mask': {
          backgroundColor: 'rgba(255, 255, 255, 0.8)',
          backdropFilter: 'blur(4px)',
        },
      },
    },
  },
});

export default function LazyLoading() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <ErrorBoundary>
        <BrowserRouter>      
          <Layout>
            <Routes>
              {/* Security: Explicit root route */}
              <Route path="/" element={<Login />} />
              <Route path="/login" element={<Login />} />
              
              {/* Security: Lazy loaded routes with error boundaries */}
              <Route 
                path="/home" 
                element={
                  <ProtectedRoute>
                    <LazyComponentErrorBoundary>
                      <Home />
                    </LazyComponentErrorBoundary>
                  </ProtectedRoute>
                } 
              />
              
              <Route 
                path="/dashboard" 
                element={
                  <ProtectedRoute>
                    <LazyComponentErrorBoundary>
                      <Dashboard />
                    </LazyComponentErrorBoundary>
                  </ProtectedRoute>
                }
              />
              
              <Route 
                path="/profile" 
                element={
                  <ProtectedRoute>
                    <LazyComponentErrorBoundary>
                      <Profile />
                    </LazyComponentErrorBoundary>
                  </ProtectedRoute>
                }
              />
              
              {/* Security: Catch-all route */}
              <Route path="*" element={<Login />} />
            </Routes>
          </Layout>
          
          {/* Toast Container with security configurations */}
          <ToastContainer
            position="top-right"
            autoClose={3000}
            hideProgressBar={false}
            newestOnTop={false}
            closeOnClick
            rtl={false}
            pauseOnFocusLoss
            draggable
            pauseOnHover
            theme="light"
            limit={5}
            toastClassName="secure-toast"
            bodyClassName="secure-toast-body"
          />
        </BrowserRouter>
      </ErrorBoundary>
    </ThemeProvider>
  );
}