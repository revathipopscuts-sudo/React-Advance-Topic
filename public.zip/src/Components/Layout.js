import { Box } from "@mui/material";
import Header from "./Header";
import Footer from "./Footer";
import PropTypes from 'prop-types';

// Background particles component
const BackgroundParticles = () => {
  return (
    <div className="background-particles">
      {[...Array(10)].map((_, i) => (
        <div key={i} className="particle"></div>
      ))}
    </div>
  );
};

function Layout({ children }) {
  return (
    <>
      <BackgroundParticles />
      <Box
        sx={{
          display: 'flex',
          flexDirection: 'column',
          minHeight: '100vh',
          position: 'relative',
          zIndex: 1,
        }}
      >
        <Header isLoggedIn={true} onLogout={() => console.log("Logged out")} />
        
        <Box
          component="main"
          sx={{
            flexGrow: 1,
            display: 'flex',
            flexDirection: 'column',
            position: 'relative',
            '&::before': {
              content: '""',
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              background: 'rgba(255, 255, 255, 0.02)',
              backdropFilter: 'blur(1px)',
              zIndex: -1,
            }
          }}
        >
          {children}
        </Box>
        
        <Footer />
      </Box>
    </>
  );
}

Layout.propTypes = {
  children: PropTypes.node.isRequired,
};

export default Layout;