import React from 'react';
import { Box, Typography, Button, Paper } from '@mui/material';
import PropTypes from 'prop-types';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { 
      hasError: false, 
      error: null,
      errorId: null
    };
  }

  static getDerivedStateFromError(error) {
    // Generate a secure error ID for tracking
    const errorId = `err_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
    return { 
      hasError: true, 
      error,
      errorId
    };
  }

  componentDidCatch(error, errorInfo) {
    // Security: Sanitize error information before logging
    const sanitizedError = {
      errorId: this.state.errorId,
      message: error?.message || 'Unknown error occurred',
      timestamp: new Date().toISOString(),
      // Only include stack trace in development
      stack: process.env.NODE_ENV === 'development' ? error?.stack : '[Hidden in production]',
      componentStack: process.env.NODE_ENV === 'development' ? errorInfo?.componentStack : '[Hidden in production]'
    };
    
    // Log error securely
    console.error('Application Error Boundary:', sanitizedError);
    
    // In production, send to monitoring service (without sensitive data)
    if (process.env.NODE_ENV === 'production') {
      try {
        // Example: Send to error monitoring service
        // errorMonitoringService.logError({
        //   errorId: this.state.errorId,
        //   message: error?.message,
        //   timestamp: sanitizedError.timestamp,
        //   userAgent: navigator.userAgent,
        //   url: window.location.href
        // });
      } catch (monitoringError) {
        console.warn('Failed to log error to monitoring service');
      }
    }
  }

  handleReload = () => {
    try {
      this.setState({ hasError: false, error: null, errorId: null });
      window.location.reload();
    } catch (reloadError) {
      // Fallback if reload fails
      window.location.href = '/';
    }
  };

  handleGoHome = () => {
    try {
      this.setState({ hasError: false, error: null, errorId: null });
      window.location.href = '/';
    } catch (navigationError) {
      // Force page refresh as last resort
      window.location.reload();
    }
  };

  render() {
    if (this.state.hasError) {
      return (
        <Box
          sx={{
            minHeight: '100vh',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            p: 3,
            bgcolor: '#f8f9fa'
          }}
        >
          <Paper 
            elevation={3} 
            sx={{ 
              p: 4, 
              maxWidth: 600, 
              textAlign: 'center',
              border: '1px solid #dee2e6'
            }}
          >
            <Typography variant="h4" color="error" gutterBottom>
              🚨 Application Error
            </Typography>
            <Typography variant="h6" sx={{ mb: 2, color: 'text.secondary' }}>
              We apologize for the inconvenience
            </Typography>
            <Typography variant="body1" sx={{ mb: 3 }}>
              The application encountered an unexpected error and needs to be restarted.
            </Typography>
            
            {/* Security: Only show error details in development */}
            {process.env.NODE_ENV === 'development' && this.state.error && (
              <Box sx={{ mb: 3 }}>
                <Typography variant="subtitle2" sx={{ mb: 1, color: 'warning.main' }}>
                  Development Error Details:
                </Typography>
                <Paper 
                  sx={{ 
                    p: 2, 
                    bgcolor: '#fff3cd', 
                    border: '1px solid #ffeaa7',
                    borderRadius: 1,
                    textAlign: 'left'
                  }}
                >
                  <Typography 
                    variant="body2" 
                    sx={{ 
                      fontFamily: 'monospace',
                      fontSize: '0.8rem',
                      wordBreak: 'break-word',
                      color: '#856404'
                    }}
                  >
                    <strong>Error:</strong> {this.state.error.message}
                  </Typography>
                  {this.state.errorId && (
                    <Typography 
                      variant="body2" 
                      sx={{ 
                        fontFamily: 'monospace',
                        fontSize: '0.8rem',
                        mt: 1,
                        color: '#856404'
                      }}
                    >
                      <strong>Error ID:</strong> {this.state.errorId}
                    </Typography>
                  )}
                </Paper>
              </Box>
            )}

            {/* Production: Show generic message with error ID */}
            {process.env.NODE_ENV === 'production' && this.state.errorId && (
              <Typography variant="body2" sx={{ mb: 3, color: 'text.secondary' }}>
                Error ID: {this.state.errorId}
              </Typography>
            )}
            
            <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center', flexWrap: 'wrap' }}>
              <Button 
                variant="contained" 
                onClick={this.handleReload}
                color="primary"
                size="large"
              >
                🔄 Reload Application
              </Button>
              <Button 
                variant="outlined" 
                onClick={this.handleGoHome}
                color="secondary"
                size="large"
              >
                🏠 Go to Home
              </Button>
            </Box>

            <Typography variant="caption" sx={{ mt: 3, display: 'block', color: 'text.secondary' }}>
              If this problem persists, please contact support
            </Typography>
          </Paper>
        </Box>
      );
    }

    return this.props.children;
  }
}

ErrorBoundary.propTypes = {
  children: PropTypes.node.isRequired,
};

export default ErrorBoundary;