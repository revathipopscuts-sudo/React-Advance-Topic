import { AppBar, Toolbar, Typography, Button, Box } from "@mui/material";
import { useAuth } from "../hooks";

function Header() {
  const { isAuthenticated, user, logout, isLoading } = useAuth();

  const handleNavigation = (path) => {
    try {
      window.location.href = path;
    } catch (error) {
      console.warn("Navigation failed");
    }
  };

  // Security: Don't render navigation until loading is complete
  if (isLoading) {
    return (
      <AppBar position="sticky" elevation={2}>
        <Toolbar>
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            React Forms App
          </Typography>
        </Toolbar>
      </AppBar>
    );
  }

  return (
    <AppBar position="sticky" elevation={2}>
      <Toolbar>
        <Typography 
          variant="h6" 
          component="div" 
          sx={{ flexGrow: 1, cursor: 'pointer' }}
          onClick={() => handleNavigation("/")}
        >
          React Forms App
        </Typography>
        
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          {isAuthenticated && user ? (
            <>
              <Typography 
                variant="body2"
                sx={{
                  maxWidth: '200px',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                  whiteSpace: 'nowrap'
                }}
              >
                Welcome, <strong>{user.username}</strong>!
              </Typography>
              <Button 
                color="inherit" 
                onClick={() => handleNavigation("/dashboard")}
                aria-label="Go to Dashboard"
              >
                Dashboard
              </Button>
              <Button 
                color="inherit" 
                onClick={() => handleNavigation("/home")}
                aria-label="Go to Home"
              >
                Home
              </Button>
              <Button 
                color="inherit" 
                onClick={() => handleNavigation("/profile")}
                aria-label="Go to Profile"
              >
                Profile
              </Button>
              <Button 
                color="inherit" 
                onClick={logout}
                variant="outlined"
                aria-label="Logout from application"
              >
                Logout
              </Button>
            </>
          ) : (
            // Show help button when user is NOT logged in
            <Button 
              color="inherit" 
              onClick={() => alert("Need help? Contact support at help@reactforms.com")}
              variant="outlined"
              aria-label="Get help"
            >
              Help
            </Button>
          )}
        </Box>
      </Toolbar>
    </AppBar>
  );
}

export default Header;