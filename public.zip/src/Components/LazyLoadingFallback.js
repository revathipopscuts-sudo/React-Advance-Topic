import React from 'react';
import { Box, CircularProgress, Typography, Paper } from '@mui/material';
import PropTypes from 'prop-types';

// Security: Secure loading component that provides user feedback without exposing system details
const LazyLoadingFallback = ({ 
  componentName = "content",
  showProgress = true,
  minHeight = "200px",
  message = null 
}) => {
  // Security: Sanitize component name to prevent XSS
  const sanitizedComponentName = typeof componentName === 'string' 
    ? componentName.replace(/[<>]/g, '').substring(0, 50)
    : "content";

  const displayMessage = message || `Loading ${sanitizedComponentName}...`;

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: minHeight,
        p: 3,
        width: '100%',
      }}
    >
      <Paper
        elevation={0}
        sx={{
          p: 4,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          bgcolor: 'transparent',
          border: '1px solid',
          borderColor: 'divider',
          borderRadius: 2,
          minWidth: '200px',
        }}
      >
        {showProgress && (
          <CircularProgress 
            size={40} 
            thickness={4} 
            sx={{ 
              mb: 2,
              color: 'primary.main' 
            }} 
          />
        )}
        
        <Typography 
          variant="body1" 
          sx={{ 
            color: 'text.secondary',
            textAlign: 'center',
            fontWeight: 500,
            userSelect: 'none' // Security: Prevent text selection
          }}
        >
          {displayMessage}
        </Typography>
        
        <Typography 
          variant="caption" 
          sx={{ 
            mt: 1,
            color: 'text.disabled',
            textAlign: 'center',
            userSelect: 'none'
          }}
        >
          Please wait...
        </Typography>
      </Paper>
    </Box>
  );
};

LazyLoadingFallback.propTypes = {
  componentName: PropTypes.string,
  showProgress: PropTypes.bool,
  minHeight: PropTypes.string,
  message: PropTypes.string,
};

export default LazyLoadingFallback;