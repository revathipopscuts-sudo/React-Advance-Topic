import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLocalStorage } from './useLocalStorage';
import { toastService } from '../services/toastService';

// Custom hook for authentication management
export const useAuth = () => {
  const navigate = useNavigate();
  const [token, setToken, removeToken] = useLocalStorage('token', null);
  const [user, setUser, removeUser] = useLocalStorage('user', null);
  const [username, setUsername, removeUsername] = useLocalStorage('username', null);
  
  const [isLoading, setIsLoading] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Check authentication status
  useEffect(() => {
    const checkAuth = () => {
      if (token && user) {
        setIsAuthenticated(true);
      } else {
        setIsAuthenticated(false);
      }
    };
    checkAuth();
  }, [token, user]);

  // Login function
  const login = useCallback(async (credentials) => {
    setIsLoading(true);
    try {
      const { username: inputUsername, password } = credentials;
      
      // Validate inputs
      if (!inputUsername || inputUsername.length < 2) {
        throw new Error("Username must be at least 2 characters long");
      }
      if (!password || password.length < 4) {
        throw new Error("Password must be at least 4 characters long");
      }

      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Generate mock data
      const mockToken = 'mock_jwt_token_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
      const userData = { 
        username: inputUsername, 
        id: Math.floor(Math.random() * 10) + 1,
        loginTime: new Date().toISOString()
      };
      
      // Store auth data
      setToken(mockToken);
      setUser(userData);
      setUsername(inputUsername);
      
      toastService.loginSuccess(inputUsername);
      
      return { success: true, user: userData };
    } catch (error) {
      console.warn("Login failed:", error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  }, [setToken, setUser, setUsername]);

  // Logout function
  const logout = useCallback(() => {
    try {
      removeToken();
      removeUser();
      removeUsername();
      setIsAuthenticated(false);
      toastService.logoutSuccess();
      
      setTimeout(() => {
        navigate('/login', { replace: true });
      }, 500);
    } catch (error) {
      console.warn("Logout failed:", error);
      navigate('/login', { replace: true });
    }
  }, [removeToken, removeUser, removeUsername, navigate]);

  // Check if user is authenticated (for route protection)
  const requireAuth = useCallback(() => {
    if (!isAuthenticated) {
      navigate('/login', { replace: true });
      return false;
    }
    return true;
  }, [isAuthenticated, navigate]);

  // Get current user info
  const getCurrentUser = useCallback(() => {
    return user ? {
      ...user,
      username: username || user.username
    } : null;
  }, [user, username]);

  return {
    // State
    isLoading,
    isAuthenticated,
    user: getCurrentUser(),
    
    // Actions
    login,
    logout,
    requireAuth,
    
    // Utilities
    token,
    username
  };
};