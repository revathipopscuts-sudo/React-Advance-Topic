import { useState, useEffect, useCallback } from 'react';

// Custom hook for API calls with loading and error states
export const useApi = (apiFunction, dependencies = []) => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const executeApi = useCallback(async (...args) => {
    try {
      setLoading(true);
      setError(null);
      const result = await apiFunction(...args);
      setData(result);
      return result;
    } catch (err) {
      setError(err.message || 'An error occurred');
      throw err;
    } finally {
      setLoading(false);
    }
  }, [apiFunction]);

  // Auto-execute on mount if no dependencies or when dependencies change
  useEffect(() => {
    if (dependencies.length === 0) {
      executeApi();
    }
  }, dependencies);

  const refetch = useCallback(() => {
    return executeApi();
  }, [executeApi]);

  return {
    data,
    loading,
    error,
    execute: executeApi,
    refetch
  };
};

// Custom hook specifically for profile API
export const useProfile = (userId) => {
  const [profile, setProfile] = useState(null);
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchProfile = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Import API functions dynamically to avoid circular dependencies
      const { profileAPI } = await import('../services/api');
      
      const [profileData, postsData] = await Promise.all([
        profileAPI.getProfile(userId),
        profileAPI.getUserPosts(userId)
      ]);
      
      setProfile(profileData);
      setPosts(postsData.slice(0, 3)); // Show only first 3 posts
      
    } catch (err) {
      console.error('Failed to fetch profile:', err);
      setError(err.message || 'Failed to load profile data');
    } finally {
      setLoading(false);
    }
  }, [userId]);

  useEffect(() => {
    if (userId) {
      fetchProfile();
    }
  }, [userId, fetchProfile]);

  return {
    profile,
    posts,
    loading,
    error,
    refetch: fetchProfile
  };
};