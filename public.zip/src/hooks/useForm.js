import { useState, useCallback } from 'react';

// Custom hook for form handling
export const useForm = (initialValues, validationRules = {}) => {
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Handle input change
  const handleChange = useCallback((event) => {
    const { name, value, type, checked } = event.target;
    const newValue = type === 'checkbox' ? checked : value;
    
    setValues(prevValues => ({
      ...prevValues,
      [name]: newValue
    }));

    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prevErrors => ({
        ...prevErrors,
        [name]: ''
      }));
    }
  }, [errors]);

  // Handle input blur (for touched state)
  const handleBlur = useCallback((event) => {
    const { name } = event.target;
    setTouched(prevTouched => ({
      ...prevTouched,
      [name]: true
    }));

    // Validate field on blur if validation rules exist
    if (validationRules[name]) {
      validateField(name, values[name]);
    }
  }, [validationRules, values]);

  // Validate single field
  const validateField = useCallback((fieldName, value) => {
    const rules = validationRules[fieldName];
    if (!rules) return '';

    let error = '';

    // Required validation
    if (rules.required && (!value || value.toString().trim() === '')) {
      error = rules.required.message || `${fieldName} is required`;
    }
    
    // Min length validation
    else if (rules.minLength && value && value.toString().length < rules.minLength.value) {
      error = rules.minLength.message || `${fieldName} must be at least ${rules.minLength.value} characters`;
    }
    
    // Max length validation
    else if (rules.maxLength && value && value.toString().length > rules.maxLength.value) {
      error = rules.maxLength.message || `${fieldName} must be no more than ${rules.maxLength.value} characters`;
    }
    
    // Email validation
    else if (rules.email && value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
      error = rules.email.message || 'Please enter a valid email address';
    }
    
    // Custom validation
    else if (rules.custom && value) {
      const customResult = rules.custom.validate(value);
      if (customResult !== true) {
        error = customResult || rules.custom.message || 'Invalid value';
      }
    }

    setErrors(prevErrors => ({
      ...prevErrors,
      [fieldName]: error
    }));

    return error;
  }, [validationRules]);

  // Validate all fields
  const validateAll = useCallback(() => {
    const newErrors = {};
    let hasErrors = false;

    Object.keys(validationRules).forEach(fieldName => {
      const error = validateField(fieldName, values[fieldName]);
      if (error) {
        newErrors[fieldName] = error;
        hasErrors = true;
      }
    });

    setErrors(newErrors);
    return !hasErrors;
  }, [validationRules, values, validateField]);

  // Handle form submission
  const handleSubmit = useCallback((onSubmit) => {
    return async (event) => {
      event.preventDefault();
      setIsSubmitting(true);

      // Mark all fields as touched
      const allTouched = Object.keys(values).reduce((acc, key) => {
        acc[key] = true;
        return acc;
      }, {});
      setTouched(allTouched);

      // Validate all fields
      const isValid = validateAll();
      
      if (isValid) {
        try {
          await onSubmit(values);
        } catch (error) {
          console.error('Form submission error:', error);
        }
      }
      
      setIsSubmitting(false);
    };
  }, [values, validateAll]);

  // Reset form
  const reset = useCallback(() => {
    setValues(initialValues);
    setErrors({});
    setTouched({});
    setIsSubmitting(false);
  }, [initialValues]);

  // Set form values programmatically
  const setFormValues = useCallback((newValues) => {
    setValues(prevValues => ({
      ...prevValues,
      ...newValues
    }));
  }, []);

  // Check if form is valid
  const isValid = Object.keys(errors).every(key => !errors[key]);
  const hasErrors = Object.keys(errors).some(key => errors[key]);

  return {
    // Form state
    values,
    errors,
    touched,
    isSubmitting,
    isValid,
    hasErrors,
    
    // Form handlers
    handleChange,
    handleBlur,
    handleSubmit,
    
    // Utilities
    validateField,
    validateAll,
    reset,
    setFormValues
  };
};