// Export all custom hooks from a single file for easy importing
export { useLocalStorage } from './useLocalStorage';
export { useAuth } from './useAuth';
export { useForm } from './useForm';
export { useApi, useProfile } from './useApi';