import {
  Box,
  Typography,
  Card,
  CardContent,
  Avatar,
  Chip,
  Grid,
  Paper,
  CircularProgress,
  Alert
} from "@mui/material";
import { useAuth, useProfile } from "../hooks";

export default function Profile() {
  const { user: authUser } = useAuth();
  const { profile, posts, loading, error, refetch } = useProfile(authUser?.id);
  
  const userName = authUser?.username;

  if (loading) {
    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          minHeight: "70vh",
          flexDirection: "column",
          gap: 3,
          background: "linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)",
          borderRadius: 2,
          margin: 2,
          padding: 4,
          boxShadow: 3
        }}
      >
        <Box sx={{ position: "relative", display: "inline-flex" }}>
          <CircularProgress 
            size={80} 
            thickness={4}
            sx={{ 
              color: "primary.main",
              animationDuration: "550ms"
            }} 
          />
          <Box
            sx={{
              top: 0,
              left: 0,
              bottom: 0,
              right: 0,
              position: "absolute",
              display: "flex",
              alignItems: "center",
              justifyContent: "center"
            }}
          >
            <Avatar
              sx={{ 
                width: 40, 
                height: 40, 
                bgcolor: "primary.light",
                fontSize: "1.2rem"
              }}
            >
              {userName?.charAt(0) || 'U'}
            </Avatar>
          </Box>
        </Box>
        <Box sx={{ textAlign: "center" }}>
          <Typography variant="h5" color="primary.main" gutterBottom>
            Loading Profile...
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Fetching your profile data from the server
          </Typography>
        </Box>
        
        {/* Loading skeleton effect */}
        <Box sx={{ width: "100%", maxWidth: 400, mt: 2 }}>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1, mb: 1 }}>
            <Box sx={{ width: 20, height: 20, borderRadius: 1, bgcolor: "grey.300", animation: "pulse 1.5s ease-in-out infinite" }} />
            <Box sx={{ flex: 1, height: 10, borderRadius: 1, bgcolor: "grey.200", animation: "pulse 1.5s ease-in-out infinite 0.2s" }} />
          </Box>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1, mb: 1 }}>
            <Box sx={{ width: 20, height: 20, borderRadius: 1, bgcolor: "grey.300", animation: "pulse 1.5s ease-in-out infinite 0.4s" }} />
            <Box sx={{ flex: 1, height: 10, borderRadius: 1, bgcolor: "grey.200", animation: "pulse 1.5s ease-in-out infinite 0.6s" }} />
          </Box>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
            <Box sx={{ width: 20, height: 20, borderRadius: 1, bgcolor: "grey.300", animation: "pulse 1.5s ease-in-out infinite 0.8s" }} />
            <Box sx={{ flex: 1, height: 10, borderRadius: 1, bgcolor: "grey.200", animation: "pulse 1.5s ease-in-out infinite 1s" }} />
          </Box>
        </Box>

        <style>
          {`
            @keyframes pulse {
              0% { opacity: 1; }
              50% { opacity: 0.4; }
              100% { opacity: 1; }
            }
          `}
        </style>
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
        <Typography color="text.secondary">
          Showing local profile for: <b>{userName}</b>
        </Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ p: 3 }}>
      {/* Profile Header */}
      <Card elevation={3} sx={{ mb: 3 }}>
        <CardContent>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
            <Avatar
              sx={{ 
                width: 80, 
                height: 80, 
                bgcolor: 'primary.main',
                fontSize: '2rem',
                mr: 3
              }}
            >
              {profile?.name?.charAt(0) || userName?.charAt(0) || 'U'}
            </Avatar>
            <Box>
              <Typography variant="h4" gutterBottom>
                {profile?.name || userName || 'User'}
              </Typography>
              <Typography variant="subtitle1" color="text.secondary" gutterBottom>
                @{profile?.username || userName}
              </Typography>
              <Chip 
                label="Active User" 
                color="success" 
                size="small"
              />
            </Box>
          </Box>
        </CardContent>
      </Card>

      <Grid container spacing={3}>
        {/* Contact Information */}
        <Grid item xs={12} md={6}>
          <Paper elevation={2} sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom color="primary">
              Contact Information
            </Typography>
            <Box sx={{ '& > *': { mb: 1 } }}>
              <Typography><strong>Email:</strong> {profile?.email || 'N/A'}</Typography>
              <Typography><strong>Phone:</strong> {profile?.phone || 'N/A'}</Typography>
              <Typography><strong>Website:</strong> {profile?.website || 'N/A'}</Typography>
            </Box>
          </Paper>
        </Grid>

        {/* Address Information */}
        <Grid item xs={12} md={6}>
          <Paper elevation={2} sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom color="primary">
              Address
            </Typography>
            <Box sx={{ '& > *': { mb: 1 } }}>
              <Typography><strong>Street:</strong> {profile?.address?.street || 'N/A'}</Typography>
              <Typography><strong>Suite:</strong> {profile?.address?.suite || 'N/A'}</Typography>
              <Typography><strong>City:</strong> {profile?.address?.city || 'N/A'}</Typography>
              <Typography><strong>Zipcode:</strong> {profile?.address?.zipcode || 'N/A'}</Typography>
            </Box>
          </Paper>
        </Grid>

        {/* Company Information */}
        <Grid item xs={12} md={6}>
          <Paper elevation={2} sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom color="primary">
              Company
            </Typography>
            <Box sx={{ '& > *': { mb: 1 } }}>
              <Typography><strong>Name:</strong> {profile?.company?.name || 'N/A'}</Typography>
              <Typography><strong>Catchphrase:</strong> {profile?.company?.catchPhrase || 'N/A'}</Typography>
              <Typography><strong>Business:</strong> {profile?.company?.bs || 'N/A'}</Typography>
            </Box>
          </Paper>
        </Grid>

        {/* Recent Posts */}
        <Grid item xs={12} md={6}>
          <Paper elevation={2} sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom color="primary">
              Recent Posts ({posts.length})
            </Typography>
            {posts.length > 0 ? (
              posts.map((post) => (
                <Box key={post.id} sx={{ mb: 2, p: 2, bgcolor: 'grey.50', borderRadius: 1 }}>
                  <Typography variant="subtitle2" gutterBottom>
                    {post.title}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {post.body.substring(0, 100)}...
                  </Typography>
                </Box>
              ))
            ) : (
              <Typography color="text.secondary">No recent posts</Typography>
            )}
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
}
