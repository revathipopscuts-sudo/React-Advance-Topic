import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Box,
  Button,
  Typography,
  AppBar,
  Toolbar,
  Paper,
  Avatar,
  Menu,
  MenuItem,
  IconButton,
} from "@mui/material";

function stringAvatar(name = "") {
  // Utility to extract initials for avatar display
  const names = name.split(" ");
  if (names.length === 1) return names[0][0]?.toUpperCase() ?? "";
  return (names[0][0] + names[names.length - 1][0]).toUpperCase();
}

function Dashboard() {
  const navigate = useNavigate();

  // Get user info from localStorage
  // Adjust this based on how you save user info: username/email or an object
  const storedUser = localStorage.getItem("user");
  let userName = "";

  if (storedUser) {
    try {
      const user = JSON.parse(storedUser);
      userName = user.fullName || user.username || user.email || "";
    } catch {
      userName = localStorage.getItem("username") || "";
    }
  } else {
    userName = localStorage.getItem("username") || "";
  }

  // For Avatar dropdown
  const [anchorEl, setAnchorEl] = useState(null);

  useEffect(() => {
    // Protect route: redirect if no token
    if (!localStorage.getItem("token")) {
      navigate("/", { replace: true });
    }
  }, [navigate]);

  const handleAvatarClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("username");
    localStorage.removeItem("user");
    setAnchorEl(null);
    navigate("/", { replace: true });
  };

  return (
    <Box sx={{ minHeight: "100vh", bgcolor: "#f4f6f8" }}>
      {/* Top Navbar */}
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" sx={{ flexGrow: 1 }}>
            Dashboard
          </Typography>
          <Box>
            <IconButton onClick={handleAvatarClick} size="large" sx={{ p: 0 }}>
              <Avatar sx={{ bgcolor: "#673ab7" }}>
                {stringAvatar(userName)}
              </Avatar>
            </IconButton>
            <Menu
              anchorEl={anchorEl}
              open={Boolean(anchorEl)}
              onClose={handleMenuClose}
              anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
              transformOrigin={{ vertical: "top", horizontal: "right" }}
              sx={{ mt: 1 }}
            >
              <MenuItem onClick={logout}>Logout</MenuItem>
            </Menu>
          </Box>
        </Toolbar>
      </AppBar>
      {/* Content */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          mt: 6,
        }}
      >
        <Paper elevation={4} sx={{ p: 4, width: 400 }}>
          <Typography variant="h5" gutterBottom>
            Welcome 🎉
          </Typography>
          <Typography color="text.secondary" sx={{ mb: 2 }}>
            {userName ? (
              <>
                Hello, <b>{userName}</b>!
              </>
            ) : null}
            <br />
            You have successfully logged in.
            <br />
            This page is protected.
          </Typography>
        </Paper>
      </Box>
    </Box>
  );
}

export default Dashboard;
