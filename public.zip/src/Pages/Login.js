import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import CircularProgress from "@mui/material/CircularProgress";
import { Box, Button, TextField, Typography, Paper, Avatar } from "@mui/material";
import { toastService } from "../services/toastService";
import { useAuth, useForm } from "../hooks";

// Try to import Login icon, with fallback
let LoginIcon;
try {
  const icons = require('@mui/icons-material');
  LoginIcon = icons.Login;
} catch (e) {
  // Fallback if icon doesn't load
  LoginIcon = ({ sx }) => <Box sx={{ ...sx, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '2rem' }}>🔐</Box>;
}

function Login() {
  const navigate = useNavigate();
  const { login, isLoading, isAuthenticated } = useAuth();
  
  // Form validation rules
  const validationRules = {
    username: {
      required: { message: "Username is required" },
      minLength: { value: 2, message: "Username must be at least 2 characters" }
    },
    password: {
      required: { message: "Password is required" },
      minLength: { value: 4, message: "Password must be at least 4 characters" }
    }
  };

  const {
    values,
    errors,
    handleChange,
    handleBlur,
    handleSubmit,
    isValid
  } = useForm(
    { username: "", password: "" },
    validationRules
  );

  useEffect(() => {
    if (isAuthenticated) {
      navigate("/dashboard", { replace: true });
    }
  }, [isAuthenticated, navigate]);

  const onSubmit = async (formData) => {
    try {
      await login(formData);
      setTimeout(() => {
        navigate("/home", { replace: true });
      }, 800);
    } catch (err) {
      if (err.message.includes("Username") || err.message.includes("Password")) {
        toastService.error(err.message);
      } else {
        toastService.error("Invalid login credentials. Please try again.");
      }
    }
  };

  const handleKeyPress = (event) => {
    if (event.key === 'Enter') {
      handleSubmit(onSubmit)(event);
    }
  };

  return (
    <Box
      sx={{
        minHeight: "calc(100vh - 140px)",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        py: 4,
        position: "relative"
      }}
    >
      {/* Decorative background elements */}
      <Box
        sx={{
          position: "absolute",
          top: "10%",
          left: "10%",
          width: "150px",
          height: "150px",
          borderRadius: "50%",
          background: "rgba(255, 255, 255, 0.1)",
          backdropFilter: "blur(10px)",
          animation: "float 6s ease-in-out infinite"
        }}
      />
      <Box
        sx={{
          position: "absolute",
          top: "60%",
          right: "15%",
          width: "100px",
          height: "100px",
          borderRadius: "50%",
          background: "rgba(255, 255, 255, 0.08)",
          backdropFilter: "blur(10px)",
          animation: "float 4s ease-in-out infinite reverse"
        }}
      />
      
      <Paper
        elevation={0}
        className="glass-effect"
        sx={{
          p: 6,
          maxWidth: 450,
          width: "100%",
          mx: 2,
          background: "rgba(255, 255, 255, 0.1)",
          backdropFilter: "blur(20px)",
          border: "1px solid rgba(255, 255, 255, 0.2)",
          borderRadius: 4,
          boxShadow: "0 15px 35px rgba(0, 0, 0, 0.1)",
          position: "relative",
          overflow: "hidden",
          "&::before": {
            content: '\"\"',
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            height: "4px",
            background: "linear-gradient(90deg, #667eea, #764ba2, #f093fb, #f5576c)",
            backgroundSize: "200% 100%",
            animation: "shimmer 2s linear infinite"
          }
        }}
      >
        {/* Header */}
        <Box sx={{ textAlign: "center", mb: 4 }}>
          <Avatar
            sx={{
              width: 80,
              height: 80,
              mx: "auto",
              mb: 2,
              background: "linear-gradient(135deg, #667eea, #764ba2)",
              boxShadow: "0 8px 25px rgba(0,0,0,0.3)"
            }}
          >
            <LoginIcon sx={{ fontSize: 40 }} />
          </Avatar>
          <Typography
            variant="h3"
            sx={{
              fontWeight: 700,
              color: "white",
              mb: 1,
              textShadow: "2px 2px 4px rgba(0,0,0,0.3)"
            }}
          >
            Welcome Back
          </Typography>
          <Typography
            variant="body1"
            sx={{
              color: "rgba(255,255,255,0.8)",
              fontSize: "1.1rem"
            }}
          >
            Sign in to continue your journey
          </Typography>
        </Box>

        {/* Form */}
        <Box sx={{ mb: 3 }}>
          <TextField
            fullWidth
            name="username"
            label="Username"
            variant="outlined"
            value={values.username}
            onChange={handleChange}
            onBlur={handleBlur}
            onKeyPress={handleKeyPress}
            disabled={isLoading}
            error={!!errors.username}
            helperText={errors.username}
            sx={{
              mb: 3,
              '& .MuiOutlinedInput-root': {
                background: 'rgba(255, 255, 255, 0.1)',
                backdropFilter: 'blur(10px)',
                borderRadius: 2,
                '& fieldset': {
                  borderColor: 'rgba(255, 255, 255, 0.3)',
                },
                '&:hover fieldset': {
                  borderColor: 'rgba(255, 255, 255, 0.5)',
                },
                '&.Mui-focused fieldset': {
                  borderColor: '#667eea',
                },
              },
              '& .MuiInputLabel-root': {
                color: 'rgba(255, 255, 255, 0.8)',
              },
              '& .MuiOutlinedInput-input': {
                color: 'white',
              },
            }}
          />
          <TextField
            fullWidth
            name="password"
            label="Password"
            type="password"
            variant="outlined"
            value={values.password}
            onChange={handleChange}
            onBlur={handleBlur}
            onKeyPress={handleKeyPress}
            disabled={isLoading}
            error={!!errors.password}
            helperText={errors.password}
            sx={{
              '& .MuiOutlinedInput-root': {
                background: 'rgba(255, 255, 255, 0.1)',
                backdropFilter: 'blur(10px)',
                borderRadius: 2,
                '& fieldset': {
                  borderColor: 'rgba(255, 255, 255, 0.3)',
                },
                '&:hover fieldset': {
                  borderColor: 'rgba(255, 255, 255, 0.5)',
                },
                '&.Mui-focused fieldset': {
                  borderColor: '#667eea',
                },
              },
              '& .MuiInputLabel-root': {
                color: 'rgba(255, 255, 255, 0.8)',
              },
              '& .MuiOutlinedInput-input': {
                color: 'white',
              },
            }}
          />
        </Box>

        {/* Login Button */}
        <Button
          fullWidth
          variant="contained"
          size="large"
          onClick={handleSubmit(onSubmit)}
          disabled={isLoading || !isValid || !values.username.trim() || !values.password.trim()}
          className={isLoading ? "" : "pulse-button"}
          sx={{
            py: 2,
            borderRadius: 3,
            fontSize: "1.1rem",
            fontWeight: 600,
            textTransform: "none",
            background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
            boxShadow: "0 8px 25px rgba(102, 126, 234, 0.4)",
            border: "none",
            color: "white",
            position: "relative",
            overflow: "hidden",
            "&:hover": {
              background: "linear-gradient(135deg, #5a6fd8 0%, #6a4190 100%)",
              transform: "translateY(-2px)",
              boxShadow: "0 12px 35px rgba(102, 126, 234, 0.6)",
            },
            "&:disabled": {
              background: "rgba(255, 255, 255, 0.2)",
              color: "rgba(255, 255, 255, 0.5)",
              boxShadow: "none",
            },
            "&::before": {
              content: '\"\"',
              position: "absolute",
              top: 0,
              left: "-100%",
              width: "100%",
              height: "100%",
              background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent)",
              transition: "left 0.5s",
            },
            "&:hover::before": {
              left: "100%",
            },
          }}
        >
          {isLoading ? (
            <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
              <CircularProgress size={24} sx={{ color: "white" }} />
              <span>Signing In...</span>
            </Box>
          ) : (
            "Sign In"
          )}
        </Button>

        {/* Demo Info */}
        <Box sx={{ mt: 4, textAlign: "center" }}>
          <Typography
            variant="caption"
            sx={{
              color: "rgba(255, 255, 255, 0.6)",
              fontSize: "0.9rem"
            }}
          >
            Demo: Use any username (min 2 chars) and password (min 4 chars)
          </Typography>
        </Box>
      </Paper>
      
      <style>
        {`
          @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
          }
        `}
      </style>
    </Box>
  );
}

export default Login;