import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  Box,
  Typography,
  Paper,
  Card,
  CardContent,
  Grid,
  Chip,
  Avatar,
  Button
} from "@mui/material";

// Try to import icons, with fallbacks
let DashboardIcon, PersonIcon, HomeIcon, AnalyticsIcon;
try {
  const icons = require('@mui/icons-material');
  DashboardIcon = icons.Dashboard;
  PersonIcon = icons.Person;
  HomeIcon = icons.Home;
  AnalyticsIcon = icons.Analytics;
} catch (e) {
  // Fallback if icons don't load
  const FallbackIcon = ({ sx }) => <Box sx={{ ...sx, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>📊</Box>;
  DashboardIcon = FallbackIcon;
  PersonIcon = ({ sx }) => <Box sx={{ ...sx, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>👤</Box>;
  HomeIcon = ({ sx }) => <Box sx={{ ...sx, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>🏠</Box>;
  AnalyticsIcon = ({ sx }) => <Box sx={{ ...sx, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>📈</Box>;
}

function stringAvatar(name = "") {
  const names = name.split(" ");
  if (names.length === 1) return names[0][0]?.toUpperCase() ?? "";
  return (names[0][0] + names[names.length - 1][0]).toUpperCase();
}

function Home() {
  const navigate = useNavigate();

  const storedUser = localStorage.getItem("user");
  let userName = "";

  if (storedUser) {
    try {
      const user = JSON.parse(storedUser);
      userName = user.fullName || user.username || user.email || "";
    } catch {
      userName = localStorage.getItem("username") || "";
    }
  } else {
    userName = localStorage.getItem("username") || "";
  }

  useEffect(() => {
    if (!localStorage.getItem("token")) {
      navigate("/", { replace: true });
    }
  }, [navigate]);

  const quickActions = [
    {
      title: "Dashboard",
      description: "View your analytics and insights",
      icon: <DashboardIcon sx={{ fontSize: 40, color: "#667eea" }} />,
      path: "/dashboard",
      gradient: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)"
    },
    {
      title: "Profile", 
      description: "Manage your personal information",
      icon: <PersonIcon sx={{ fontSize: 40, color: "#f093fb" }} />,
      path: "/profile",
      gradient: "linear-gradient(135deg, #f093fb 0%, #f5576c 100%)"
    },
    {
      title: "Analytics",
      description: "View detailed reports and metrics", 
      icon: <AnalyticsIcon sx={{ fontSize: 40, color: "#4facfe" }} />,
      path: "/dashboard",
      gradient: "linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)"
    }
  ];

  return (
    <Box sx={{ p: 4, minHeight: "80vh" }}>
      {/* Welcome Header */}
      <Paper
        elevation={0}
        className="glass-effect"
        sx={{
          p: 4,
          mb: 4,
          textAlign: "center",
          background: "rgba(255, 255, 255, 0.1)",
          backdropFilter: "blur(20px)",
          border: "1px solid rgba(255, 255, 255, 0.2)",
          borderRadius: 4
        }}
      >
        <Avatar
          sx={{
            width: 80,
            height: 80,
            mx: "auto",
            mb: 2,
            background: "linear-gradient(135deg, #667eea, #764ba2)",
            fontSize: "2rem",
            boxShadow: "0 10px 25px rgba(0,0,0,0.2)"
          }}
        >
          {stringAvatar(userName)}
        </Avatar>
        <Typography 
          variant="h3" 
          sx={{ 
            fontWeight: 700, 
            mb: 2,
            background: "linear-gradient(45deg, #667eea, #764ba2)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            backgroundClip: "text"
          }}
        >
          Welcome Back! 🎉
        </Typography>
        <Typography variant="h5" sx={{ color: "rgba(255,255,255,0.9)", mb: 1 }}>
          Hello, <strong>{userName}</strong>!
        </Typography>
        <Chip
          icon={<HomeIcon />}
          label="You're in the Home page"
          sx={{
            background: "rgba(255,255,255,0.2)",
            color: "white",
            backdropFilter: "blur(10px)"
          }}
        />
      </Paper>

      {/* Quick Actions Grid */}
      <Typography 
        variant="h4" 
        sx={{ 
          mb: 3, 
          color: "white",
          textAlign: "center",
          fontWeight: 600,
          textShadow: "2px 2px 4px rgba(0,0,0,0.3)"
        }}
      >
        Quick Actions
      </Typography>
      
      <Grid container spacing={3} justifyContent="center">
        {quickActions.map((action, index) => (
          <Grid item xs={12} sm={6} md={4} key={index}>
            <Card
              className="enhanced-card"
              sx={{
                background: "rgba(255, 255, 255, 0.1)",
                backdropFilter: "blur(20px)",
                border: "1px solid rgba(255, 255, 255, 0.2)",
                borderRadius: 4,
                height: "100%",
                transition: "all 0.3s ease",
                cursor: "pointer",
                position: "relative",
                overflow: "hidden",
                "&:hover": {
                  transform: "translateY(-8px)",
                  boxShadow: "0 20px 40px rgba(0,0,0,0.3)",
                  "& .action-icon": {
                    transform: "scale(1.1) rotate(5deg)"
                  }
                },
                "&::before": {
                  content: '\"\"',
                  position: "absolute",
                  top: 0,
                  left: 0,
                  right: 0,
                  height: "4px",
                  background: action.gradient,
                  borderRadius: "16px 16px 0 0"
                }
              }}
              onClick={() => navigate(action.path)}
            >
              <CardContent sx={{ textAlign: "center", p: 3 }}>
                <Box
                  className="action-icon"
                  sx={{
                    mb: 2,
                    transition: "all 0.3s ease",
                    display: "inline-block"
                  }}
                >
                  {action.icon}
                </Box>
                <Typography 
                  variant="h6" 
                  sx={{ 
                    fontWeight: 600, 
                    mb: 1,
                    color: "white"
                  }}
                >
                  {action.title}
                </Typography>
                <Typography 
                  variant="body2" 
                  sx={{ 
                    color: "rgba(255,255,255,0.8)",
                    mb: 2
                  }}
                >
                  {action.description}
                </Typography>
                <Button
                  variant="contained"
                  size="small"
                  sx={{
                    background: action.gradient,
                    color: "white",
                    border: "none",
                    borderRadius: 2,
                    textTransform: "none",
                    fontWeight: 600,
                    "&:hover": {
                      opacity: 0.9,
                      transform: "scale(1.05)"
                    }
                  }}
                >
                  Explore
                </Button>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Stats Section */}
      <Paper
        className="glass-effect"
        sx={{
          mt: 4,
          p: 3,
          background: "rgba(255, 255, 255, 0.1)",
          backdropFilter: "blur(20px)",
          border: "1px solid rgba(255, 255, 255, 0.2)",
          borderRadius: 4
        }}
      >
        <Typography variant="h6" sx={{ color: "white", mb: 2, textAlign: "center" }}>
          Your Activity Today
        </Typography>
        <Grid container spacing={2} justifyContent="center">
          {[
            { label: "Profile Views", value: "24", color: "#667eea" },
            { label: "Tasks Completed", value: "8", color: "#f093fb" },
            { label: "Active Sessions", value: "3", color: "#4facfe" }
          ].map((stat, index) => (
            <Grid item xs={4} key={index}>
              <Box sx={{ textAlign: "center" }}>
                <Typography 
                  variant="h4" 
                  sx={{ 
                    fontWeight: 700,
                    color: stat.color,
                    mb: 0.5
                  }}
                >
                  {stat.value}
                </Typography>
                <Typography 
                  variant="caption" 
                  sx={{ color: "rgba(255,255,255,0.8)" }}
                >
                  {stat.label}
                </Typography>
              </Box>
            </Grid>
          ))}
        </Grid>
      </Paper>
    </Box>
  );
}

export default Home;