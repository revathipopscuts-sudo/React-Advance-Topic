import "./styles.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { lazy, Suspense } from "react";
import ProtectedRoute from "./Components/ProtectedRoute";
import Login from "./Pages/Login";
import Layout from "./Components/Layout";
import LazyLoadingFallback from "./Components/LazyLoadingFallback";
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { CssBaseline } from "@mui/material";
import { ToastContainer } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import ErrorBoundary from "./Components/ErrorBoundary";

// Security: Enhanced lazy loading with secure error handling
const createSecureLazyComponent = (importFunc, componentName) => {
  return lazy(() => 
    importFunc().catch(error => {
      // Security: Log error securely without exposing sensitive information
      console.error(`Failed to load ${componentName} component:`, {
        message: error.message,
        timestamp: new Date().toISOString(),
        component: componentName
      });
      
      // Return secure fallback component
      return { 
        default: () => (
          <LazyLoadingFallback 
            componentName={componentName}
            message={`Unable to load ${componentName}. Please refresh the page.`}
            showProgress={false}
          />
        )
      };
    })
  );
};

// Security: Create lazy components with secure error handling
const Dashboard = createSecureLazyComponent(
  () => import("./Pages/Dashboard"), 
  "Dashboard"
);

const Profile = createSecureLazyComponent(
  () => import("./Pages/Profile"), 
  "Profile"
);

const Home = createSecureLazyComponent(
  () => import("./Pages/Home"), 
  "Home"
);

// Security: Secure wrapper for lazy components
const SecureLazyRoute = ({ children, componentName }) => (
  <ErrorBoundary>
    <Suspense fallback={<LazyLoadingFallback componentName={componentName} />}>
      {children}
    </Suspense>
  </ErrorBoundary>
);

const theme = createTheme({
  palette: {
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#42a5f5',
    },
  },
  components: {
    MuiCssBaseline: {
      styleOverrides: {
        '.no-select': {
          userSelect: 'none',
          webkitUserSelect: 'none',
          mozUserSelect: 'none',
          msUserSelect: 'none',
        },
        // Security: Secure loading styles
        '.secure-loading': {
          backgroundColor: 'rgba(255, 255, 255, 0.9)',
          backdropFilter: 'blur(8px)',
          borderRadius: '8px',
        },
        '.secure-toast': {
          borderRadius: '8px !important',
          backdropFilter: 'blur(10px)',
        },
        '.secure-toast-body': {
          userSelect: 'none',
          wordBreak: 'break-word',
        },
      },
    },
  },
});

export default function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <ErrorBoundary>
        <BrowserRouter>      
          <Layout>
            <Routes>
              {/* Security: Explicit root route */}
              <Route path="/" element={<Login />} />
              <Route path="/login" element={<Login />} />
              
              {/* Security: Lazy loaded routes with enhanced error boundaries */}
              <Route 
                path="/home" 
                element={
                  <ProtectedRoute>
                    <SecureLazyRoute componentName="Home">
                      <Home />
                    </SecureLazyRoute>
                  </ProtectedRoute>
                } 
              />
              
              <Route 
                path="/dashboard" 
                element={
                  <ProtectedRoute>
                    <SecureLazyRoute componentName="Dashboard">
                      <Dashboard />
                    </SecureLazyRoute>
                  </ProtectedRoute>
                }
              />
              
              <Route 
                path="/profile" 
                element={
                  <ProtectedRoute>
                    <SecureLazyRoute componentName="Profile">
                      <Profile />
                    </SecureLazyRoute>
                  </ProtectedRoute>
                }
              />
              
              {/* Security: Catch-all route */}
              <Route path="*" element={<Login />} />
            </Routes>
          </Layout>
          
          {/* Security: Enhanced Toast Container */}
          <ToastContainer
            position="top-right"
            autoClose={3000}
            hideProgressBar={false}
            newestOnTop={false}
            closeOnClick
            rtl={false}
            pauseOnFocusLoss
            draggable
            pauseOnHover
            theme="light"
            limit={5}
            toastClassName="secure-toast"
            bodyClassName="secure-toast-body"
            progressClassName="secure-toast-progress"
          />
        </BrowserRouter>
      </ErrorBoundary>
    </ThemeProvider>
  );
}