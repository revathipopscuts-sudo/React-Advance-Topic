import { toast } from 'react-toastify';

// Security: Input sanitization function
const sanitizeInput = (input) => {
  if (typeof input !== 'string') return '';
  return input
    .replace(/[<>]/g, '') // Remove potential HTML tags
    .replace(/javascript:/gi, '') // Remove javascript: protocol
    .replace(/on\w+=/gi, '') // Remove event handlers
    .trim();
};

export const toastService = {
  success: (message, options = {}) => {
    const sanitizedMessage = sanitizeInput(message);
    toast.success(sanitizedMessage, {
      position: "top-right",
      autoClose: 3000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      ...options
    });
  },

  error: (message, options = {}) => {
    const sanitizedMessage = sanitizeInput(message);
    toast.error(sanitizedMessage, {
      position: "top-right",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      ...options
    });
  },

  warning: (message, options = {}) => {
    const sanitizedMessage = sanitizeInput(message);
    toast.warning(sanitizedMessage, {
      position: "top-right",
      autoClose: 4000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      ...options
    });
  },

  info: (message, options = {}) => {
    const sanitizedMessage = sanitizeInput(message);
    toast.info(sanitizedMessage, {
      position: "top-right",
      autoClose: 3000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      ...options
    });
  },

  // Security: Login success with user validation
  loginSuccess: (username) => {
    const sanitizedUsername = sanitizeInput(username);
    if (sanitizedUsername) {
      toast.success(`Welcome back, ${sanitizedUsername}!`, {
        position: "top-right",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
      });
    } else {
      toast.success('Login successful!');
    }
  },

  // Security: Logout message without user data
  logoutSuccess: () => {
    toast.info('You have been logged out successfully', {
      position: "top-right",
      autoClose: 2000,
    });
  }
};