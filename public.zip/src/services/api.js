import axios from 'axios';

// Create axios instance with base configuration
export const api = axios.create({
  baseURL: 'https://jsonplaceholder.typicode.com', // Using a mock API for demo
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000,
});

// Add request interceptor to include auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add response interceptor to handle common responses
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    if (error.response?.status === 401) {
      // Token expired or invalid
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      localStorage.removeItem('username');
      window.location.href = '/';
    }
    return Promise.reject(error);
  }
);

// Profile API functions
export const profileAPI = {
  // Get user profile by ID
  getProfile: async (userId = 1) => {
    try {
      // JSONPlaceholder only has users 1-10, so validate the userId
      let validUserId = userId;
      if (userId > 10 || userId < 1) {
        // Generate a random valid user ID (1-10) for JSONPlaceholder
        validUserId = Math.floor(Math.random() * 10) + 1;
        console.log(`User ID ${userId} not available. Using fallback ID: ${validUserId}`);
      }
      
      const response = await api.get(`/users/${validUserId}`);
      return response.data;
    } catch (error) {
      // If still 404, try with user ID 1 as final fallback
      if (error.response?.status === 404) {
        console.log('User not found, falling back to default user (ID: 1)');
        try {
          const fallbackResponse = await api.get('/users/1');
          return fallbackResponse.data;
        } catch (fallbackError) {
          console.error('Even fallback failed:', fallbackError);
          throw fallbackError;
        }
      }
      console.error('Error fetching profile:', error);
      throw error;
    }
  },

  // Get user posts
  getUserPosts: async (userId = 1) => {
    try {
      // JSONPlaceholder only has users 1-10, so validate the userId
      let validUserId = userId;
      if (userId > 10 || userId < 1) {
        validUserId = Math.floor(Math.random() * 10) + 1;
      }
      
      const response = await api.get(`/users/${validUserId}/posts`);
      return response.data;
    } catch (error) {
      // If 404, try with user ID 1
      if (error.response?.status === 404) {
        try {
          const fallbackResponse = await api.get('/users/1/posts');
          return fallbackResponse.data;
        } catch (fallbackError) {
          console.error('Posts fallback failed:', fallbackError);
          return []; // Return empty array if all fails
        }
      }
      console.error('Error fetching user posts:', error);
      return []; // Return empty array on error
    }
  },

  // Get user albums
  getUserAlbums: async (userId = 1) => {
    try {
      // JSONPlaceholder only has users 1-10, so validate the userId
      let validUserId = userId;
      if (userId > 10 || userId < 1) {
        validUserId = Math.floor(Math.random() * 10) + 1;
      }
      
      const response = await api.get(`/users/${validUserId}/albums`);
      return response.data;
    } catch (error) {
      // If 404, try with user ID 1
      if (error.response?.status === 404) {
        try {
          const fallbackResponse = await api.get('/users/1/albums');
          return fallbackResponse.data;
        } catch (fallbackError) {
          console.error('Albums fallback failed:', fallbackError);
          return []; // Return empty array if all fails
        }
      }
      console.error('Error fetching user albums:', error);
      return []; // Return empty array on error
    }
  }
};